Test Partage .cs
